# py-office-learn
 py-office-learn is a gui for machine learning
